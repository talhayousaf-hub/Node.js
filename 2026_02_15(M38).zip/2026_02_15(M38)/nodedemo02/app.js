const {Product, Category, PerishableProduct} =require("./mymodules/oopdemo01");

const c1=new Category(1,"mobiles","mobiles.png");
const c2=new Category(1,"laptops","laptops.png");


// const p1=new Product(1,"aaaa",1000,18,c1);
// const p2=new Product(2,"bbbb",1500,10);
// const p3=new Product(4,"cccc",700,20);

// p1.Price=99;


// console.log(p2.Price);


//console.log(Product.Counter);

// console.log(c1.Details)

// console.log(p1.Category.Name);

// console.log(p1.Details);


// const pp1=new PerishableProduct(1,"aaaa",1000,18,c1,new Date(2026,1,15),new Date(2029,1,15));

// const pp2=new PerishableProduct(2,"bbbb",7500,10,c1);


// console.log(pp2.Name);
// console.log(pp2.MfgDate);
// //console.log(pp2.MfgDate.toDateString());

// console.log(pp1.Details);
// console.log(pp1.Summary);

const data=[
    new PerishableProduct(1,"aaaa",1000,18,c1,new Date(2026,1,15),new Date(2029,1,15)),
    new PerishableProduct(2,"bbbb",600,10,c2,new Date(2025,10,1),new Date(2028,10,1)),
    new PerishableProduct(3,"ccc",1400,0,c1,new Date(2025,12,6),new Date(2030,12,6))
];


data.forEach(d=> console.log(d.Details));