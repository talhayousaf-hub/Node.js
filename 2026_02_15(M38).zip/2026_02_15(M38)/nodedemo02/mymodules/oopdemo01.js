
class Category {
    constructor(id, name, image) {
        this.Id = id;
        this.Name = name;
        this.Image = image;
    }

    get Summary() {
        return `${this.Id},${this.Name}`
    }

    get Details() {
        return `${this.Id},${this.Name},${this.Image}`;
    }
}

class Product {
    //static / shared / class members
    //They are defined using static keyword
    //They are used with class name
    //Their value is shared for all objects 
    // They are loaded in memory when class is first time used in a program
    // They are available through execution of the program 

    //static _Counter;

    static get Counter() {
        return Product._Counter;
    }
    // static set Counter(value){
    //     if(value<0) throw TypeError("counter can't be zero");
    //     Product._Counter=value;
    // }


    static {
        Product._Counter = 550;
    }

    constructor(id, name, price, gstRate, Category) {
        Product._Counter++;
        this.Id = id;
        this.Name = name;
        this.Price = price;
        this.GstRate = gstRate;
        this.Category = Category;
    }

    get Category() {
        return this._Category;
    }

    set Category(value) {
        if (value) {
            if (!(value instanceof Category)) throw TypeError("category must be an object of Category class");
            this._Category = value;
        }
    }


    set Id(value) {
        if (value != undefined) {
            if (value < 1) throw TypeError("id can't be zero or negative number");
            this._Id = value;
        }
    }


    get Id() {
        return this._Id;
    }


    set Price(value) {
        if (value != undefined) {
            if (value < 0) throw TypeError("price can't be negative");
            this._Price = value
        }
    }
    get Price() {
        return this._Price;
    }


    set Name(value) {
        if (value) {
            if (value.length < 3 || value.length > 50) throw TypeError("name must have 3 to 50 carachters");
            this._Name = value;
        }
    }


    get Name() {
        return this._Name;
    }

    set GstRate(value) {
        if (value != undefined) {
            if (value < 0 || value > 100) throw TypeError("GST rate must be from 0 to 100");
            this._GstRate = value;
        }
    }


    get GstRate() {
        return this._GstRate;
    }

    get GstAmount() {
        return this.Price * this.GstRate / 100;
    }

    get RetailPrice() {
        return this.Price + this.GstAmount;
    }

    get Summary() {
        return `${this.Id},${this.Name},${this.RetailPrice}`;
    }

    get Details() {
        return `${this.Id},${this.Name},${this.Price},${this.GstAmount},${this.RetailPrice},${this.Category.Name}`;
    }




}

//PerishableProduct class inherits Product class
//Product class: Parent Classs, Base Class, Super Class, Inherited Class, General Class
//PerishableProduct class: Child class, Sub class, Drieved classs, Special class
//child class consturctor must call super class constructor 
class PerishableProduct extends Product {

    constructor(id, name, price, gstRate, category, mfgDate, expDate) {
        super(id, name, price, gstRate, category);
        this.MfgDate = mfgDate;
        this.ExpDate = expDate;
    }

    get MfgDate() {
        return this._MfgDate;
    }

    set MfgDate(value) {
        if (value) {
            if (!(value instanceof Date)) throw TypeError("MfgDate must be an object of Date type");
            this._MfgDate = value;
        }
    }


     get ExpDate() {
        return this._ExpDate;
    }

    set ExpDate(value) {
        if (value) {
            if (!(value instanceof Date)) throw TypeError("MfgDate must be an object of Date type");
            this._ExpDate = value;
        }
    }

    //This method shadows inherited method from parent class
    get Details(){
        //same class
        // this.Details
        //parent class method
        const temp =super.Details;
        return `${temp},${this.MfgDate.toDateString()},${this.ExpDate.toDateString()}`;
    }

    get Summary(){
        const temp =super.Summary;
        return `${temp},${this.ExpDate.toDateString()}`;
    }



}

module.exports = {
    Product,
    Category,
    PerishableProduct
}