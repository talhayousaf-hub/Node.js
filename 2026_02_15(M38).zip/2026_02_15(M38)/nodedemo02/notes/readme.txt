1- Download and install nodejs
  - when you install node npm is also installed with it
  - To check nodejs and npm is working execute folling command in cmd prompt (or terminal in vs code)
    node -v
    npm -v

2- npm init:   To create / initialize node projects
   it creates package.json file for your project with initial data


3- Node Golbals
  they are directly available in our node code 
  - Global Variables
    - __filename  : current file name
    - __dirname   :  root folder 

  - Global objects (the most common)
    - console 
    - process

4- Node Modules / Node packages
  - Builtin Modules : They are installed with node and available for use 
  - Our own modules / Custom Modules : They are created by us and we can use them 
  - Third party modules: They are created by anybody else and we have install these modules before using them

  - Builtin Modules (the most common)
    - os : for information related to operating system
    - path : for information relate to folder/file path 
  - Third party modules 
    - colors : this third party module is used to add colorful output on console
    - dotenv : this third party module is used to read data from configuration file (.env)
    
    
  




Common cli commands
- cls : clear screen
- cd : change directory (folder)
  cd images\categories  : change directory to images\categories

- mkdir : make directory (folder) 
  mkdir abc    : creates abc director in current directory 
- dir : show list of files and directories 


  



